(()=>{var m={START_RECORDING:"startRecording",STOP_RECORDING:"stopRecording",START_SESSION:"startSession",STOP_SESSION:"stopSession",RECORD_STEP:"recordStep",CAPTURE_SCREENSHOT:"captureScreenshot",GET_STATUS:"getStatus"},j={SCREENSHOT:3e3,INPUT_DEBOUNCE:1e3,VALIDATION_WINDOW:2e3,DUPLICATE_CLICK:1e3,DUPLICATE_STEP:5e3,NETWORK_SLOW:2e3,RECENT_INPUT_MAX_AGE:3e4,API_CORRELATION_WINDOW:2e3,CLICK_TRACKING_MAX_AGE:5e3},R={captureClicks:!0,captureInputs:!0,captureNavigation:!0,captureScroll:!1,captureErrors:!1,captureValidation:!0,captureNetwork:!1,includeTimestamps:!0,includeUrls:!0,includeScreenshots:!0,screenshotQuality:25};var M={isRecording:!1,steps:[],settings:R,recordingSessionId:null,activeSessionDomain:null};async function w(e=null){let n=e||Object.keys(M),r=await chrome.storage.local.get(n);return n.reduce((t,o)=>(t[o]=r[o]??M[o],t),{})}async function k(e){await chrome.storage.local.set(e)}function O(e){let n=r=>{let t={};for(let[o,{newValue:c}]of Object.entries(r))t[o]=c;e(t)};return chrome.storage.onChanged.addListener(n),()=>chrome.storage.onChanged.removeListener(n)}function v(e){let n=document.getElementById("status"),r=document.getElementById("statusText"),t=document.getElementById("statusDot"),o=document.getElementById("startBtn"),c=document.getElementById("stopBtn");e?(r.textContent="Recording",n.className="status recording",t.style.display="block",o.style.display="none",c.style.display="block"):(r.textContent="Ready",n.className="status stopped",t.style.display="none",o.style.display="block",c.style.display="none")}function b(e){let n=e===0?"No steps recorded":`${e} step${e===1?"":"s"} recorded`;document.getElementById("stepCount").textContent=n}function A(e){e&&Object.keys(e).forEach(n=>{let r=document.getElementById(n);r&&(r.type==="checkbox"?r.checked=e[n]:r.tagName==="SELECT"&&(r.value=e[n]))})}function C(){return{captureClicks:document.getElementById("captureClicks").checked,captureInputs:document.getElementById("captureInputs").checked,captureNavigation:document.getElementById("captureNavigation").checked,captureScroll:document.getElementById("captureScroll").checked,captureErrors:document.getElementById("captureErrors").checked,captureValidation:document.getElementById("captureValidation").checked,captureNetwork:document.getElementById("captureNetwork").checked,includeTimestamps:document.getElementById("includeTimestamps").checked,includeUrls:document.getElementById("includeUrls").checked,includeScreenshots:document.getElementById("includeScreenshots").checked,screenshotQuality:parseInt(document.getElementById("screenshotQuality").value,10)}}function D(){["captureClicks","captureInputs","captureNavigation","captureScroll","captureErrors","captureValidation","captureNetwork","includeTimestamps","includeUrls","includeScreenshots","screenshotQuality"].forEach(n=>{let r=document.getElementById(n);r&&r.addEventListener("change",async()=>{let t=C();await k({settings:t})})})}var q=`
    * { box-sizing: border-box; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 1400px; margin: 0 auto; padding: 20px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px; border-radius: 16px; margin-bottom: 24px; box-shadow: 0 10px 40px rgba(102, 126, 234, 0.3); }
    .header h1 { margin: 0 0 12px 0; font-size: 32px; font-weight: 700; }
    .header .meta { opacity: 0.95; font-size: 14px; display: flex; gap: 20px; flex-wrap: wrap; }
    .filter-panel { background: white; padding: 24px; border-radius: 12px; margin-bottom: 24px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border: 1px solid rgba(102, 126, 234, 0.1); }
    .filter-panel h3 { margin: 0 0 8px 0; color: #2d3748; font-size: 18px; font-weight: 600; }
    .filter-panel > p { margin: 0 0 16px 0; color: #718096; font-size: 14px; }
    .filter-options { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 16px; }
    .filter-option.screenshot-filter { background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%); border: 2px solid #cbd5e0; width: 100%; margin-top: 10px; padding-top: 10px; }
    .filter-option { display: flex; align-items: center; background: #f7fafc; padding: 8px 12px; border-radius: 8px; transition: all 0.2s; border: 2px solid transparent; }
    .filter-option:hover { background: #edf2f7; border-color: #667eea; }
    .filter-option input { margin-right: 8px; cursor: pointer; width: 18px; height: 18px; }
    .filter-option label { cursor: pointer; font-size: 13px; font-weight: 500; user-select: none; }
    .filter-buttons { margin-top: 16px; display: flex; gap: 10px; }
    .filter-buttons button { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 13px; transition: all 0.2s; }
    .btn-all { background: #667eea; color: white; box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3); }
    .btn-none { background: #e2e8f0; color: #4a5568; }
    .btn-all:hover { background: #5568d3; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4); }
    .btn-none:hover { background: #cbd5e0; }
    .btn-compact { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3); }
    .btn-compact:hover { background: linear-gradient(135deg, #5568d3 0%, #6a3ba2 100%); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4); }
    .btn-compact.active { background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%); box-shadow: 0 2px 8px rgba(46, 125, 50, 0.3); }
    .step.compacted-hidden { display: none !important; }
    .compact-summary { background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%); padding: 16px; border-radius: 8px; margin-bottom: 20px; border: 2px solid #81c784; display: none; }
    .compact-summary.active { display: block; }
    .compact-summary h3 { margin: 0 0 8px 0; color: #2e7d32; font-size: 16px; }
    .compact-summary p { margin: 4px 0; color: #1b5e20; font-size: 14px; }
    .summary { background: white; padding: 24px; border-radius: 12px; margin-bottom: 24px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-left: 4px solid #667eea; }
    .summary h2 { margin: 0 0 12px 0; color: #2d3748; font-size: 20px; font-weight: 600; }
    .summary p { color: #4a5568; line-height: 1.6; margin: 8px 0; }
    .step { background: white; padding: 20px; margin-bottom: 16px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); border-left: 4px solid #667eea; transition: all 0.3s; position: relative; overflow: hidden; }
    .step::before { content: ''; position: absolute; top: 0; left: 0; width: 4px; height: 100%; background: linear-gradient(180deg, #667eea 0%, #764ba2 100%); transition: width 0.3s; }
    .step:hover { box-shadow: 0 8px 24px rgba(102, 126, 234, 0.15); transform: translateY(-2px); }
    .step:hover::before { width: 6px; }
    .step.hidden { display: none; }
    .step-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
    .step-number { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 6px 14px; border-radius: 20px; font-weight: 700; font-size: 13px; min-width: 36px; text-align: center; box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3); }
    .step-time { color: #718096; font-size: 12px; background: #f7fafc; padding: 6px 10px; border-radius: 6px; font-weight: 500; border: 1px solid #e2e8f0; }
    .step-type { display: inline-block; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.8px; }
    .type-click { background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); color: #0d47a1; border: 2px solid #90caf9; box-shadow: 0 2px 4px rgba(13, 71, 161, 0.1); }
    .type-input { background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%); color: #4a148c; border: 2px solid #ce93d8; box-shadow: 0 2px 4px rgba(74, 20, 140, 0.1); }
    .type-navigation { background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%); color: #1b5e20; border: 2px solid #a5d6a7; box-shadow: 0 2px 4px rgba(27, 94, 32, 0.1); }
    .type-error { background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%); color: #b71c1c; border: 2px solid #ef9a9a; box-shadow: 0 2px 4px rgba(183, 28, 28, 0.1); }
    .type-validation { background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%); color: #c62828; border: 2px solid #ef9a9a; box-shadow: 0 2px 4px rgba(198, 40, 40, 0.15); font-weight: 700; }
    .type-scroll { background: linear-gradient(135deg, #fce4ec 0%, #f8bbd0 100%); color: #880e4f; border: 2px solid #f48fb1; box-shadow: 0 2px 4px rgba(136, 14, 79, 0.1); }
    .type-network { background: linear-gradient(135deg, #e1f5fe 0%, #b3e5fc 100%); color: #01579b; border: 2px solid #81d4fa; box-shadow: 0 2px 4px rgba(1, 87, 155, 0.1); }
    .type-network.failed { background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%); color: #b71c1c; border: 2px solid #ef9a9a; }
    .type-network.slow { background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%); color: #e65100; border: 2px solid #ffcc80; }
    .step-description { font-size: 16px; color: #2d3748; margin: 10px 0 14px 0; line-height: 1.6; font-weight: 500; }
    .step-details { background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%); padding: 16px; border-radius: 8px; margin-top: 14px; font-size: 13px; border: 1px solid #e2e8f0; }
    .step-details div { margin: 8px 0; display: flex; gap: 12px; align-items: baseline; }
    .step-details strong { color: #667eea; min-width: 80px; font-weight: 700; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
    .step-details div:first-child { margin-top: 0; }
    .step-details div:last-child { margin-bottom: 0; }
    .url { color: #1976d2; word-break: break-all; }
    .screenshot { max-width: 250px; height: auto; border-radius: 8px; margin-top: 14px; cursor: pointer; transition: all 0.4s ease; box-shadow: 0 4px 12px rgba(0,0,0,0.1); border: 2px solid #e2e8f0; }
    .screenshot:hover, .screenshot.expanded { max-width: 1250px; border-color: #667eea; box-shadow: 0 12px 40px rgba(102, 126, 234, 0.3); }
    .footer { text-align: center; color: #718096; margin-top: 40px; padding: 30px; background: white; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    .footer p { margin: 8px 0; font-size: 14px; }
    .visible-count { color: #667eea; font-weight: 700; margin-top: 12px; font-size: 14px; padding: 8px 16px; background: #f7fafc; border-radius: 8px; display: inline-block; border: 2px solid #e2e8f0; }
    
    /* Network Card Styles - Chrome DevTools inspired */
    .network-card { background: #1e1e1e; border-radius: 8px; overflow: hidden; margin-top: 12px; font-family: 'SF Mono', 'Fira Code', 'Monaco', 'Consolas', monospace; max-height: 550px; display: flex; flex-direction: column; }
    .network-card-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: linear-gradient(135deg, #2d2d2d 0%, #1e1e1e 100%); border-bottom: 1px solid #3d3d3d; flex-shrink: 0; }
    .network-method { font-weight: 700; font-size: 12px; padding: 4px 10px; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
    .method-get { background: #1565c0; color: #fff; }
    .method-post { background: #2e7d32; color: #fff; }
    .method-put { background: #f57c00; color: #fff; }
    .method-patch { background: #7b1fa2; color: #fff; }
    .method-delete { background: #c62828; color: #fff; }
    .network-url { color: #9cdcfe; font-size: 13px; word-break: break-all; flex: 1; }
    .network-status { display: flex; align-items: center; gap: 8px; }
    .status-code { font-weight: 700; font-size: 13px; padding: 3px 8px; border-radius: 4px; }
    .status-success { background: rgba(46, 125, 50, 0.2); color: #81c784; }
    .status-error { background: rgba(198, 40, 40, 0.2); color: #ef9a9a; }
    .status-warning { background: rgba(245, 124, 0, 0.2); color: #ffb74d; }
    .network-duration { color: #888; font-size: 12px; }
    .network-tabs { display: flex; background: #252526; border-bottom: 1px solid #3d3d3d; flex-shrink: 0; }
    .network-search { display: flex; align-items: center; gap: 8px; padding: 8px 12px; background: #252526; border-bottom: 1px solid #3d3d3d; flex-shrink: 0; }
    .network-search-input { flex: 1; background: #1e1e1e; border: 1px solid #3d3d3d; border-radius: 4px; padding: 6px 10px; color: #d4d4d4; font-size: 12px; outline: none; transition: border-color 0.2s; }
    .network-search-input:focus { border-color: #4fc3f7; }
    .network-search-input::placeholder { color: #6d6d6d; }
    .network-search-results { font-size: 11px; color: #888; white-space: nowrap; }
    .network-search-results.has-results { color: #4fc3f7; }
    .network-search-results.no-results { color: #f48771; }
    .network-search-clear { background: transparent; border: none; color: #888; cursor: pointer; font-size: 14px; padding: 4px 8px; border-radius: 4px; transition: all 0.2s; }
    .network-search-clear:hover { background: #3d3d3d; color: #fff; }
    .network-search-nav { background: transparent; border: none; color: #888; cursor: pointer; font-size: 10px; padding: 2px 6px; border-radius: 3px; transition: all 0.2s; }
    .network-search-nav:hover { background: #3d3d3d; color: #4fc3f7; }
    .search-highlight { background: #614d0a; color: #fff; border-radius: 2px; padding: 0 2px; }
    .search-highlight.current { background: #f57c00; color: #fff; box-shadow: 0 0 4px rgba(245, 124, 0, 0.5); }
    .network-tab { padding: 10px 20px; color: #888; font-size: 12px; font-weight: 600; cursor: pointer; border-bottom: 2px solid transparent; transition: all 0.2s; text-transform: uppercase; letter-spacing: 0.5px; }
    .network-tab:hover { color: #ddd; background: rgba(255,255,255,0.05); }
    .network-tab.active { color: #4fc3f7; border-bottom-color: #4fc3f7; background: rgba(79, 195, 247, 0.05); }
    .network-content { display: none; flex: 1; overflow: auto; min-height: 0; }
    .network-content.expanded { }
    .json-actions { display: flex; gap: 8px; padding: 8px 16px 0; }
    .json-action-btn { background: #3d3d3d; color: #ddd; border: none; padding: 6px 12px; border-radius: 4px; font-size: 11px; cursor: pointer; transition: all 0.2s; }
    .json-action-btn:hover { background: #4fc3f7; color: #1e1e1e; }
    .json-action-btn.active { background: #4fc3f7; color: #1e1e1e; }
    .raw-json-view { display: none; background: #1a1a1a; padding: 16px; font-family: 'SF Mono', 'Fira Code', monospace; font-size: 12px; line-height: 1.5; color: #d4d4d4; white-space: pre; overflow-x: auto; }
    .raw-json-view.active { display: block; }
    .network-content.active { display: block; }
    .network-content::-webkit-scrollbar { width: 8px; height: 8px; }
    .network-content::-webkit-scrollbar-track { background: #1e1e1e; }
    .network-content::-webkit-scrollbar-thumb { background: #555; border-radius: 4px; }
    .network-content::-webkit-scrollbar-thumb:hover { background: #666; }
    
    /* JSON Tree Viewer Styles */
    .json-tree { padding: 16px; font-size: 13px; line-height: 1.6; color: #d4d4d4; min-width: max-content; }
    .json-tree-line { display: flex; align-items: flex-start; white-space: nowrap; }
    .json-tree-toggle { width: 16px; height: 16px; display: inline-flex; align-items: center; justify-content: center; cursor: pointer; color: #888; font-size: 10px; margin-right: 4px; user-select: none; flex-shrink: 0; }
    .json-tree-toggle:hover { color: #fff; }
    .json-tree-toggle.collapsed::before { content: '\u25B6'; }
    .json-tree-toggle.expanded::before { content: '\u25BC'; }
    .json-tree-toggle.empty { visibility: hidden; }
    .json-tree-key { color: #9cdcfe; }
    .json-tree-string { color: #ce9178; }
    .json-tree-number { color: #b5cea8; }
    .json-tree-boolean { color: #569cd6; }
    .json-tree-null { color: #569cd6; font-style: italic; }
    .json-tree-bracket { color: #808080; }
    .json-tree-comma { color: #808080; }
    .json-tree-colon { color: #808080; margin: 0 4px; }
    .json-tree-children { margin-left: 20px; }
    .json-tree-children.collapsed { display: none; }
    .json-tree-preview { color: #888; font-style: italic; margin-left: 6px; }
    .json-tree-copy-btn { background: #3d3d3d; color: #ddd; border: none; padding: 6px 12px; border-radius: 4px; font-size: 11px; cursor: pointer; margin: 8px 16px 16px; transition: all 0.2s; }
    .json-tree-copy-btn:hover { background: #4fc3f7; color: #1e1e1e; }
    
    /* Info Panel for network card */
    .network-info-panel { padding: 16px; overflow-x: auto; }
    .network-info-row { display: flex; padding: 8px 0; border-bottom: 1px solid #2d2d2d; white-space: nowrap; }
    .network-info-row:last-child { border-bottom: none; }
    .network-info-label { color: #888; font-size: 12px; min-width: 140px; text-transform: uppercase; letter-spacing: 0.5px; }
    .network-info-value { color: #d4d4d4; font-size: 13px; }
    .network-info-value.error { color: #ef9a9a; }
    .network-info-value.success { color: #81c784; }
    
    /* Field Mapping Styles */
    .field-mapping { margin-top: 12px; padding: 12px; background: rgba(102, 126, 234, 0.1); border-radius: 6px; border: 1px solid rgba(102, 126, 234, 0.2); }
    .field-mapping-title { font-size: 11px; color: #667eea; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 8px; font-weight: 600; }
    .field-mapping-item { display: flex; align-items: center; gap: 8px; padding: 4px 0; font-size: 12px; color: #4a5568; }
    .field-mapping-prop { color: #667eea; font-weight: 600; font-family: 'SF Mono', monospace; }
    .field-mapping-value { color: #2d3748; }
    .field-mapping-source { background: #e8f5e9; color: #2e7d32; padding: 2px 6px; border-radius: 4px; font-weight: 500; }
`;function u(e){return e==null?"":String(e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}function I(e){return e?(typeof e=="string"?e:JSON.stringify(e)).replace(/</g,"\\u003c").replace(/>/g,"\\u003e").replace(/&/g,"\\u0026"):null}function P(e,n=null){try{let r=n||(typeof window<"u"?window.location.origin:"http://localhost");return new URL(e,r).pathname}catch{return e}}function T(e){if(!e)return"";if(typeof e=="string")try{let n=JSON.parse(e);return JSON.stringify(n,null,2)}catch{return e}return JSON.stringify(e,null,2)}var L={password:/password|passwd|pwd|pass/i,apiKey:/api[_-]?key|apikey|secret|api[_-]?secret/i,creditCard:/^\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}$/};function z(e){return e?Object.values(L).some(n=>n.test(e)):!1}function _(e){return!e||typeof e!="string"?!1:Object.values(L).some(n=>n.test(e))}function W(e){if(!e||typeof e!="string")return e;let n=e.length;return n<=4?"****":L.creditCard.test(e)?"**** **** **** "+e.replace(/\D/g,"").slice(-4):e.substring(0,4)+"..."+e.substring(n-4)}function f(e,n=""){if(e==null)return e;if(typeof e=="string")return z(n)||_(e)?W(e):e;if(Array.isArray(e))return e.map(r=>f(r,n));if(typeof e=="object"){let r={};for(let[t,o]of Object.entries(e))r[t]=f(o,t);return r}return e}function E(e){if(!e)return e;let n={...e};return n.details&&(n.details.fieldType==="password"&&n.details.value?n.details={...n.details,value:"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"}:n.details=f(n.details)),n}function J(e,n,r,t){let o=t.method||"GET",c=`method-${o.toLowerCase()}`,s=t.isFailed?"status-error":t.isSlow?"status-warning":"status-success",d=t.isFailed?"failed":t.isSlow?"slow":"",y=t.url||"";try{let S=new URL(t.url);y=S.pathname+S.search}catch{}let h=t.requestBody?I(f(t.requestBody)):null,x=t.responseBody?I(f(t.responseBody)):null,a=`network-${n}`,l="";t.fieldMappings&&t.fieldMappings.length>0&&(l=`
      <div class="field-mapping">
        <div class="field-mapping-title">\u{1F4CA} Field Mappings (Input \u2192 API)</div>
        ${t.fieldMappings.map(g=>({...g,value:f(g.value,g.propPath)})).map(g=>`
          <div class="field-mapping-item">
            <span class="field-mapping-prop">${u(g.propPath)}</span>
            <span>:</span>
            <span class="field-mapping-value">"${u(String(g.value))}"</span>
            <span>\u2190</span>
            <span class="field-mapping-source">${u(g.sourceField)}</span>
          </div>
        `).join("")}
      </div>
    `);let B=e.priority||(t.isFailed?"critical":t.isSlow?"high":"medium");return`
    <div class="step" data-type="network" data-step-index="${n}" data-priority="${B}" data-captured-priority="${B}">
      <div class="step-header">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span class="step-number">${n+1}</span>
          <span class="step-type type-network ${d}">NETWORK</span>
        </div>
        ${r.includeTimestamps?`<span class="step-time">${new Date(e.timestamp).toLocaleTimeString()}</span>`:""}
      </div>
      
      ${t.triggeredBy?`<div style="font-size: 12px; color: #718096; margin-bottom: 8px;">\u{1F5B1}\uFE0F Triggered by: ${u(t.triggeredBy)}</div>`:""}
      
      <div class="network-card">
        <div class="network-card-header">
          <span class="network-method ${c}">${o}</span>
          <span class="network-url">${u(y)}</span>
          <div class="network-status">
            <span class="status-code ${s}">${t.status||"\u2014"} ${t.statusText||""}</span>
            <span class="network-duration">${t.duration?`${(t.duration/1e3).toFixed(2)}s`:"\u2014"}</span>
          </div>
        </div>
        
        <div class="network-tabs">
          <div class="network-tab active" onclick="switchNetworkTab(this, '${a}', 'info')">Overview</div>
          ${h?`<div class="network-tab" onclick="switchNetworkTab(this, '${a}', 'request')">Request</div>`:""}
          ${x?`<div class="network-tab" onclick="switchNetworkTab(this, '${a}', 'response')">Response</div>`:""}
        </div>
        
        <div class="network-search">
          <input type="text" class="network-search-input" id="${a}-search" placeholder="\u{1F50D} Search in request/response..." oninput="searchInNetworkCard('${a}', this.value)">
          <span class="network-search-results" id="${a}-search-results"></span>
          <button class="network-search-nav" id="${a}-search-prev" onclick="searchPrev('${a}')" style="display: none;" title="Previous match">\u25B2</button>
          <button class="network-search-nav" id="${a}-search-next" onclick="searchNext('${a}')" style="display: none;" title="Next match">\u25BC</button>
          <button class="network-search-clear" id="${a}-search-clear" onclick="clearNetworkSearch('${a}')" style="display: none;">\u2715</button>
        </div>
        
        <!-- Overview Tab -->
        <div id="${a}-info" class="network-content active">
          <div class="network-info-panel">
            <div class="network-info-row">
              <span class="network-info-label">Request URL</span>
              <span class="network-info-value">${u(t.url||"\u2014")}</span>
            </div>
            <div class="network-info-row">
              <span class="network-info-label">Request Method</span>
              <span class="network-info-value">${o}</span>
            </div>
            <div class="network-info-row">
              <span class="network-info-label">Status Code</span>
              <span class="network-info-value ${t.isFailed?"error":"success"}">${t.status||"\u2014"} ${t.statusText||""}</span>
            </div>
            <div class="network-info-row">
              <span class="network-info-label">Duration</span>
              <span class="network-info-value">${t.duration?`${t.duration}ms (${(t.duration/1e3).toFixed(2)}s)`:"\u2014"}</span>
            </div>
            ${t.errorMessage?`
              <div class="network-info-row">
                <span class="network-info-label">Error Message</span>
                <span class="network-info-value error">${u(t.errorMessage)}</span>
              </div>
            `:""}
          </div>
        </div>
        
        ${h?`
          <!-- Request Tab -->
          <div id="${a}-request" class="network-content">
            <div class="json-actions">
              <button class="json-action-btn" onclick="copyJsonToClipboard('${a}-request-data')">\u{1F4CB} Copy</button>
              <button class="json-action-btn" onclick="expandAllJson('${a}-request-tree')">\u2795 Expand All</button>
              <button class="json-action-btn" onclick="collapseAllJson('${a}-request-tree')">\u2796 Collapse All</button>
              <button class="json-action-btn" onclick="toggleRawJson('${a}-request')">\u{1F4C4} Raw JSON</button>
            </div>
            <div class="json-tree" id="${a}-request-tree"></div>
            <div class="raw-json-view" id="${a}-request-raw"></div>
            <script type="application/json" id="${a}-request-data">${h}<\/script>
          </div>
        `:""}
        
        ${x?`
          <!-- Response Tab -->
          <div id="${a}-response" class="network-content">
            <div class="json-actions">
              <button class="json-action-btn" onclick="copyJsonToClipboard('${a}-response-data')">\u{1F4CB} Copy</button>
              <button class="json-action-btn" onclick="expandAllJson('${a}-response-tree')">\u2795 Expand All</button>
              <button class="json-action-btn" onclick="collapseAllJson('${a}-response-tree')">\u2796 Collapse All</button>
              <button class="json-action-btn" onclick="toggleRawJson('${a}-response')">\u{1F4C4} Raw JSON</button>
            </div>
            <div class="json-tree" id="${a}-response-tree"></div>
            <div class="raw-json-view" id="${a}-response-raw"></div>
            <script type="application/json" id="${a}-response-data">${x}<\/script>
          </div>
        `:""}
      </div>
      
      ${l}
      
      ${e.screenshot?`<img src="${e.screenshot}" class="screenshot" alt="Screenshot" onmouseenter="expandScreenshot(this)" title="Hover to expand, click outside to collapse">`:""}
    </div>
  `}var H=`
    let currentExpandedScreenshot = null;
    
    function expandScreenshot(img) {
      if (currentExpandedScreenshot && currentExpandedScreenshot !== img) {
        currentExpandedScreenshot.classList.remove('expanded');
      }
      img.classList.add('expanded');
      currentExpandedScreenshot = img;
    }
    
    document.addEventListener('click', function(e) {
      if (currentExpandedScreenshot && !e.target.classList.contains('screenshot')) {
        currentExpandedScreenshot.classList.remove('expanded');
        currentExpandedScreenshot = null;
      }
    });
    
    // ==========================================
    // Network Card Functions
    // ==========================================
    
    function switchNetworkTab(tabEl, cardId, tabName) {
      const card = tabEl.closest('.network-card');
      card.querySelectorAll('.network-tab').forEach(t => t.classList.remove('active'));
      card.querySelectorAll('.network-content').forEach(c => c.classList.remove('active'));
      tabEl.classList.add('active');
      const content = document.getElementById(cardId + '-' + tabName);
      if (content) {
        content.classList.add('active');
        const treeContainer = content.querySelector('.json-tree');
        const dataScript = content.querySelector('script[type="application/json"]');
        if (treeContainer && dataScript && !treeContainer.hasChildNodes()) {
          try {
            const jsonData = JSON.parse(dataScript.textContent);
            renderJsonTree(treeContainer, jsonData);
          } catch (e) {
            treeContainer.innerHTML = '<div style="color: #ce9178; padding: 8px;">' + escapeHtmlJs(dataScript.textContent) + '</div>';
          }
        }
      }
    }
    
    function renderJsonTree(container, data, depth = 0) {
      container.innerHTML = '';
      const tree = createJsonNode(data, depth, true);
      container.appendChild(tree);
    }
    
    function createJsonNode(value, depth, isRoot = false) {
      const wrapper = document.createElement('div');
      if (value === null) {
        wrapper.innerHTML = '<span class="json-tree-null">null</span>';
        return wrapper;
      }
      if (typeof value === 'boolean') {
        wrapper.innerHTML = '<span class="json-tree-boolean">' + value + '</span>';
        return wrapper;
      }
      if (typeof value === 'number') {
        wrapper.innerHTML = '<span class="json-tree-number">' + value + '</span>';
        return wrapper;
      }
      if (typeof value === 'string') {
        wrapper.innerHTML = '<span class="json-tree-string">"' + escapeHtmlJs(value) + '"</span>';
        return wrapper;
      }
      if (Array.isArray(value)) {
        return createArrayNode(value, depth, isRoot);
      }
      if (typeof value === 'object') {
        return createObjectNode(value, depth, isRoot);
      }
      wrapper.textContent = String(value);
      return wrapper;
    }
    
    function createObjectNode(obj, depth, isRoot) {
      const wrapper = document.createElement('div');
      const keys = Object.keys(obj);
      if (keys.length === 0) {
        wrapper.innerHTML = '<span class="json-tree-bracket">{}</span>';
        return wrapper;
      }
      const header = document.createElement('div');
      header.className = 'json-tree-line';
      const toggle = document.createElement('span');
      toggle.className = 'json-tree-toggle ' + (isRoot || depth < 2 ? 'expanded' : 'collapsed');
      toggle.onclick = () => toggleJsonNode(toggle);
      header.appendChild(toggle);
      const bracket = document.createElement('span');
      bracket.className = 'json-tree-bracket';
      bracket.textContent = '{';
      header.appendChild(bracket);
      const preview = document.createElement('span');
      preview.className = 'json-tree-preview';
      preview.textContent = keys.length + ' properties';
      preview.style.display = (isRoot || depth < 2) ? 'none' : 'inline';
      header.appendChild(preview);
      wrapper.appendChild(header);
      const children = document.createElement('div');
      children.className = 'json-tree-children' + ((isRoot || depth < 2) ? '' : ' collapsed');
      keys.forEach((key, idx) => {
        const row = document.createElement('div');
        row.className = 'json-tree-line';
        const keySpan = document.createElement('span');
        keySpan.className = 'json-tree-key';
        keySpan.textContent = '"' + key + '"';
        row.appendChild(keySpan);
        const colon = document.createElement('span');
        colon.className = 'json-tree-colon';
        colon.textContent = ':';
        row.appendChild(colon);
        const valueNode = createJsonNode(obj[key], depth + 1);
        row.appendChild(valueNode);
        if (idx < keys.length - 1) {
          const comma = document.createElement('span');
          comma.className = 'json-tree-comma';
          comma.textContent = ',';
          row.appendChild(comma);
        }
        children.appendChild(row);
      });
      wrapper.appendChild(children);
      const closeBracket = document.createElement('div');
      closeBracket.innerHTML = '<span class="json-tree-bracket">}</span>';
      closeBracket.style.marginLeft = '20px';
      wrapper.appendChild(closeBracket);
      return wrapper;
    }
    
    function createArrayNode(arr, depth, isRoot) {
      const wrapper = document.createElement('div');
      if (arr.length === 0) {
        wrapper.innerHTML = '<span class="json-tree-bracket">[]</span>';
        return wrapper;
      }
      const header = document.createElement('div');
      header.className = 'json-tree-line';
      const toggle = document.createElement('span');
      toggle.className = 'json-tree-toggle ' + (isRoot || depth < 2 ? 'expanded' : 'collapsed');
      toggle.onclick = () => toggleJsonNode(toggle);
      header.appendChild(toggle);
      const bracket = document.createElement('span');
      bracket.className = 'json-tree-bracket';
      bracket.textContent = '[';
      header.appendChild(bracket);
      const preview = document.createElement('span');
      preview.className = 'json-tree-preview';
      preview.textContent = arr.length + ' items';
      preview.style.display = (isRoot || depth < 2) ? 'none' : 'inline';
      header.appendChild(preview);
      wrapper.appendChild(header);
      const children = document.createElement('div');
      children.className = 'json-tree-children' + ((isRoot || depth < 2) ? '' : ' collapsed');
      arr.forEach((item, idx) => {
        const row = document.createElement('div');
        row.className = 'json-tree-line';
        const indexSpan = document.createElement('span');
        indexSpan.className = 'json-tree-key';
        indexSpan.textContent = idx;
        indexSpan.style.color = '#b5cea8';
        row.appendChild(indexSpan);
        const colon = document.createElement('span');
        colon.className = 'json-tree-colon';
        colon.textContent = ':';
        row.appendChild(colon);
        const valueNode = createJsonNode(item, depth + 1);
        row.appendChild(valueNode);
        if (idx < arr.length - 1) {
          const comma = document.createElement('span');
          comma.className = 'json-tree-comma';
          comma.textContent = ',';
          row.appendChild(comma);
        }
        children.appendChild(row);
      });
      wrapper.appendChild(children);
      const closeBracket = document.createElement('div');
      closeBracket.innerHTML = '<span class="json-tree-bracket">]</span>';
      closeBracket.style.marginLeft = '20px';
      wrapper.appendChild(closeBracket);
      return wrapper;
    }
    
    function toggleJsonNode(toggle) {
      const isExpanded = toggle.classList.contains('expanded');
      const wrapper = toggle.closest('div').parentElement;
      const children = wrapper.querySelector('.json-tree-children');
      const preview = toggle.parentElement.querySelector('.json-tree-preview');
      if (isExpanded) {
        toggle.classList.remove('expanded');
        toggle.classList.add('collapsed');
        if (children) children.classList.add('collapsed');
        if (preview) preview.style.display = 'inline';
      } else {
        toggle.classList.remove('collapsed');
        toggle.classList.add('expanded');
        if (children) children.classList.remove('collapsed');
        if (preview) preview.style.display = 'none';
      }
    }
    
    function copyJsonToClipboard(dataId) {
      const dataScript = document.getElementById(dataId);
      if (dataScript) {
        try {
          const jsonData = JSON.parse(dataScript.textContent);
          const formatted = JSON.stringify(jsonData, null, 2);
          navigator.clipboard.writeText(formatted).then(() => {
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = '\u2713 Copied!';
            btn.style.background = '#2e7d32';
            setTimeout(() => {
              btn.textContent = originalText;
              btn.style.background = '';
            }, 1500);
          });
        } catch (e) {
          navigator.clipboard.writeText(dataScript.textContent);
        }
      }
    }
    
    function expandAllJson(treeId) {
      const tree = document.getElementById(treeId);
      if (!tree) return;
      const collapsedToggles = tree.querySelectorAll('.json-tree-toggle.collapsed');
      let count = 0;
      collapsedToggles.forEach(toggle => {
        toggleJsonNode(toggle);
        count++;
      });
      showButtonFeedback(event.target, '\u2713 Expanded ' + count);
    }
    
    function collapseAllJson(treeId) {
      const tree = document.getElementById(treeId);
      if (!tree) return;
      const expandedToggles = Array.from(tree.querySelectorAll('.json-tree-toggle.expanded'));
      let count = 0;
      expandedToggles.slice(1).forEach(toggle => {
        toggleJsonNode(toggle);
        count++;
      });
      showButtonFeedback(event.target, '\u2713 Collapsed ' + count);
    }
    
    function showButtonFeedback(btn, message) {
      if (!btn) return;
      const originalText = btn.textContent;
      btn.textContent = message;
      btn.style.background = '#2e7d32';
      setTimeout(() => {
        btn.textContent = originalText;
        btn.style.background = '';
      }, 1000);
    }
    
    function toggleRawJson(contentId) {
      const content = document.getElementById(contentId);
      if (!content) return;
      const tree = content.querySelector('.json-tree');
      const rawView = content.querySelector('.raw-json-view');
      const dataScript = content.querySelector('script[type="application/json"]');
      const toggleBtn = content.querySelector('.json-action-btn:last-child');
      if (rawView.classList.contains('active')) {
        rawView.classList.remove('active');
        tree.style.display = 'block';
        if (toggleBtn) {
          toggleBtn.textContent = '\u{1F4C4} Raw JSON';
          toggleBtn.classList.remove('active');
        }
      } else {
        if (dataScript && rawView.innerHTML === '') {
          try {
            const jsonData = JSON.parse(dataScript.textContent);
            rawView.textContent = JSON.stringify(jsonData, null, 2);
          } catch (e) {
            rawView.textContent = dataScript.textContent;
          }
        }
        rawView.classList.add('active');
        tree.style.display = 'none';
        if (toggleBtn) {
          toggleBtn.textContent = '\u{1F333} Tree View';
          toggleBtn.classList.add('active');
        }
      }
    }
    
    // ==========================================
    // Network Search Functions
    // ==========================================
    
    const searchState = {};
    
    function searchInNetworkCard(cardId, query) {
      const resultsEl = document.getElementById(cardId + '-search-results');
      const clearBtn = document.getElementById(cardId + '-search-clear');
      const prevBtn = document.getElementById(cardId + '-search-prev');
      const nextBtn = document.getElementById(cardId + '-search-next');
      clearSearchHighlights(cardId);
      searchState[cardId] = { matches: [], currentIndex: 0 };
      if (!query || query.length < 2) {
        resultsEl.textContent = '';
        resultsEl.className = 'network-search-results';
        clearBtn.style.display = 'none';
        prevBtn.style.display = 'none';
        nextBtn.style.display = 'none';
        return;
      }
      clearBtn.style.display = 'block';
      const searchLower = query.toLowerCase();
      const requestData = document.getElementById(cardId + '-request-data');
      if (requestData) {
        highlightInJsonTree(cardId + '-request-tree', searchLower);
        highlightInRawView(cardId + '-request-raw', requestData.textContent, searchLower);
      }
      const responseData = document.getElementById(cardId + '-response-data');
      if (responseData) {
        highlightInJsonTree(cardId + '-response-tree', searchLower);
        highlightInRawView(cardId + '-response-raw', responseData.textContent, searchLower);
      }
      const searchInput = document.getElementById(cardId + '-search');
      let allHighlights = [];
      if (searchInput) {
        const card = searchInput.closest('.network-card');
        if (card) {
          const activeContents = card.querySelectorAll('.network-content.active');
          activeContents.forEach(content => {
            allHighlights = allHighlights.concat(Array.from(content.querySelectorAll('.search-highlight')));
          });
        }
      }
      searchState[cardId].matches = allHighlights;
      const totalMatches = searchState[cardId].matches.length;
      if (totalMatches > 0) {
        resultsEl.className = 'network-search-results has-results';
        prevBtn.style.display = 'inline-block';
        nextBtn.style.display = 'inline-block';
        searchState[cardId].currentIndex = 0;
        updateCurrentMatch(cardId);
      } else {
        resultsEl.textContent = 'No matches';
        resultsEl.className = 'network-search-results no-results';
        prevBtn.style.display = 'none';
        nextBtn.style.display = 'none';
      }
    }
    
    function updateCurrentMatch(cardId) {
      const state = searchState[cardId];
      if (!state || state.matches.length === 0) return;
      state.matches.forEach(m => m.classList.remove('current'));
      const currentMatch = state.matches[state.currentIndex];
      if (currentMatch) {
        currentMatch.classList.add('current');
        scrollToMatch(currentMatch);
      }
      const resultsEl = document.getElementById(cardId + '-search-results');
      resultsEl.textContent = (state.currentIndex + 1) + ' of ' + state.matches.length;
    }
    
    function scrollToMatch(element) {
      if (!element) return;
      const container = element.closest('.network-content');
      if (container) {
        let elementTop = 0;
        let elementLeft = 0;
        let currentElement = element;
        while (currentElement && currentElement !== container) {
          elementTop += currentElement.offsetTop;
          elementLeft += currentElement.offsetLeft;
          currentElement = currentElement.offsetParent;
        }
        const containerHeight = container.clientHeight;
        const elementHeight = element.offsetHeight;
        const targetScrollTop = elementTop - (containerHeight / 2) + (elementHeight / 2);
        container.scrollTo({ top: Math.max(0, targetScrollTop), behavior: 'smooth' });
        const containerWidth = container.clientWidth;
        const elementWidth = element.offsetWidth;
        if (elementLeft < container.scrollLeft) {
          container.scrollTo({ left: Math.max(0, elementLeft - 20), behavior: 'smooth' });
        } else if (elementLeft + elementWidth > container.scrollLeft + containerWidth) {
          container.scrollTo({ left: elementLeft + elementWidth - containerWidth + 20, behavior: 'smooth' });
        }
      } else {
        element.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      }
    }
    
    function searchNext(cardId) {
      const state = searchState[cardId];
      if (!state || state.matches.length === 0) return;
      state.currentIndex = (state.currentIndex + 1) % state.matches.length;
      updateCurrentMatch(cardId);
    }
    
    function searchPrev(cardId) {
      const state = searchState[cardId];
      if (!state || state.matches.length === 0) return;
      state.currentIndex = (state.currentIndex - 1 + state.matches.length) % state.matches.length;
      updateCurrentMatch(cardId);
    }
    
    function highlightInJsonTree(treeId, query) {
      const tree = document.getElementById(treeId);
      if (!tree) return 0;
      let matches = 0;
      const textNodes = getTextNodes(tree);
      textNodes.forEach(node => {
        const text = node.textContent;
        const lowerText = text.toLowerCase();
        if (lowerText.includes(query)) {
          const parent = node.parentElement;
          if (parent && !parent.classList.contains('search-highlight')) {
            const regex = new RegExp('(' + escapeRegex(query) + ')', 'gi');
            const parts = text.split(regex);
            if (parts.length > 1) {
              const fragment = document.createDocumentFragment();
              parts.forEach(part => {
                if (part.toLowerCase() === query) {
                  const mark = document.createElement('mark');
                  mark.className = 'search-highlight';
                  mark.textContent = part;
                  fragment.appendChild(mark);
                  matches++;
                } else {
                  fragment.appendChild(document.createTextNode(part));
                }
              });
              node.replaceWith(fragment);
            }
          }
        }
      });
      return matches;
    }
    
    function highlightInRawView(rawId, jsonText, query) {
      const rawView = document.getElementById(rawId);
      if (!rawView) return 0;
      const lowerText = jsonText.toLowerCase();
      let matches = 0;
      let pos = 0;
      while ((pos = lowerText.indexOf(query, pos)) !== -1) {
        matches++;
        pos += query.length;
      }
      if (matches > 0 && rawView.classList.contains('active')) {
        const regex = new RegExp('(' + escapeRegex(query) + ')', 'gi');
        rawView.innerHTML = escapeHtmlJs(jsonText).replace(regex, '<mark class="search-highlight">$1</mark>');
      }
      return matches;
    }
    
    function getTextNodes(element) {
      const nodes = [];
      const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null, false);
      let node;
      while (node = walker.nextNode()) {
        if (node.textContent.trim()) {
          nodes.push(node);
        }
      }
      return nodes;
    }
    
    function escapeRegex(str) {
      return str.replace(/[-\\/\\\\^$*+?.()|[\\]{}]/g, '\\\\$&');
    }
    
    function clearSearchHighlights(cardId) {
      ['request', 'response'].forEach(type => {
        const tree = document.getElementById(cardId + '-' + type + '-tree');
        const rawView = document.getElementById(cardId + '-' + type + '-raw');
        const dataScript = document.getElementById(cardId + '-' + type + '-data');
        if (tree) {
          if (dataScript) {
            try {
              const jsonData = JSON.parse(dataScript.textContent);
              renderJsonTree(tree, jsonData);
            } catch (e) {}
          }
        }
        if (rawView && dataScript) {
          try {
            const jsonData = JSON.parse(dataScript.textContent);
            rawView.textContent = JSON.stringify(jsonData, null, 2);
          } catch (e) {
            rawView.textContent = dataScript.textContent;
          }
        }
      });
    }
    
    function clearNetworkSearch(cardId) {
      const input = document.getElementById(cardId + '-search');
      const resultsEl = document.getElementById(cardId + '-search-results');
      const clearBtn = document.getElementById(cardId + '-search-clear');
      const prevBtn = document.getElementById(cardId + '-search-prev');
      const nextBtn = document.getElementById(cardId + '-search-next');
      if (input) input.value = '';
      if (resultsEl) {
        resultsEl.textContent = '';
        resultsEl.className = 'network-search-results';
      }
      if (clearBtn) clearBtn.style.display = 'none';
      if (prevBtn) prevBtn.style.display = 'none';
      if (nextBtn) nextBtn.style.display = 'none';
      searchState[cardId] = { matches: [], currentIndex: 0 };
      clearSearchHighlights(cardId);
    }
    
    function escapeHtmlJs(str) {
      if (str === null || str === undefined) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }
    
    document.addEventListener('DOMContentLoaded', function() {
      document.querySelectorAll('.network-content.active').forEach(content => {
        const treeContainer = content.querySelector('.json-tree');
        const dataScript = content.querySelector('script[type="application/json"]');
        if (treeContainer && dataScript && !treeContainer.hasChildNodes()) {
          try {
            const jsonData = JSON.parse(dataScript.textContent);
            renderJsonTree(treeContainer, jsonData);
          } catch (e) {
            treeContainer.innerHTML = '<div style="color: #ce9178;">' + escapeHtmlJs(dataScript.textContent) + '</div>';
          }
        }
      });
    });
    
    // ==========================================
    // Filter Functions
    // ==========================================
    
    function filterSteps() {
      document.getElementById('filter-validation-only').checked = false;
      document.getElementById('filter-api-only').checked = false;
      const checkboxes = document.querySelectorAll('.filter-option input[type="checkbox"]:not(#filter-screenshots):not(#filter-validation-only):not(#filter-api-only)');
      const selectedTypes = Array.from(checkboxes).filter(cb => cb.checked).map(cb => cb.value);
      const steps = document.querySelectorAll('.step');
      let visibleCount = 0;
      steps.forEach(step => {
        const stepType = step.getAttribute('data-type');
        if (selectedTypes.includes(stepType)) {
          step.classList.remove('hidden');
          visibleCount++;
        } else {
          step.classList.add('hidden');
        }
      });
      document.getElementById('visibleCount').textContent = 'Showing ' + visibleCount + ' of ' + steps.length + ' steps';
    }
    

    
    function toggleScreenshots() {
      const showScreenshots = document.getElementById('filter-screenshots').checked;
      const screenshots = document.querySelectorAll('.screenshot');
      screenshots.forEach(img => {
        img.style.display = showScreenshots ? 'block' : 'none';
      });
    }
    
    function toggleValidationOnly() {
      const validationOnly = document.getElementById('filter-validation-only').checked;
      if (validationOnly) {
        document.getElementById('filter-api-only').checked = false;
        const steps = document.querySelectorAll('.step');
        steps.forEach(step => {
          const type = step.getAttribute('data-type');
          if (type === 'validation' || type === 'error') {
            step.classList.remove('hidden');
          } else {
            step.classList.add('hidden');
          }
        });
      } else {
        filterSteps();
      }
      updateVisibleCount();
    }
    
    function toggleAPIOnly() {
      const apiOnly = document.getElementById('filter-api-only').checked;
      if (apiOnly) {
        document.getElementById('filter-validation-only').checked = false;
        const steps = document.querySelectorAll('.step');
        steps.forEach(step => {
          const type = step.getAttribute('data-type');
          if (type === 'network') {
            step.classList.remove('hidden');
          } else {
            step.classList.add('hidden');
          }
        });
      } else {
        filterSteps();
      }
      updateVisibleCount();
    }
    
    function updateVisibleCount() {
      const steps = document.querySelectorAll('.step');
      const visibleSteps = Array.from(steps).filter(s => !s.classList.contains('hidden'));
      document.getElementById('visibleCount').textContent = 'Showing ' + visibleSteps.length + ' of ' + steps.length + ' steps';
    }
    
    let compactMode = false;
    let allStepsData = [];
    
    function toggleCompactMode() {
      compactMode = !compactMode;
      const btn = document.getElementById('compactBtn');
      const summary = document.getElementById('compactSummary');
      if (compactMode) {
        btn.textContent = '\u{1F4CB} Show All Steps';
        btn.classList.add('active');
        applyCompactMode();
        summary.classList.add('active');
      } else {
        btn.textContent = '\u{1F3AF} Compact View';
        btn.classList.remove('active');
        showAllSteps();
        summary.classList.remove('active');
      }
    }
    
    function applyCompactMode() {
      const steps = document.querySelectorAll('.step');
      allStepsData = Array.from(steps).map(step => ({
        element: step,
        type: step.getAttribute('data-type'),
        index: parseInt(step.getAttribute('data-step-index'))
      }));
      const priorities = calculateStepPriorities(allStepsData);
      let keptCount = 0;
      steps.forEach((step, index) => {
        const priority = priorities[index];
        step.setAttribute('data-priority', priority);
        if (priority === 'critical' || priority === 'high') {
          step.classList.remove('compacted-hidden');
          step.classList.add('priority-badge');
          keptCount++;
        } else {
          step.classList.add('compacted-hidden');
          step.classList.remove('priority-badge');
        }
      });
      updateCompactSummary(steps.length, keptCount);
    }
    
    function showAllSteps() {
      const steps = document.querySelectorAll('.step');
      steps.forEach(step => {
        step.classList.remove('compacted-hidden');
        step.classList.remove('priority-badge');
        step.removeAttribute('data-priority');
      });
    }
    
    function calculateStepPriorities(stepsData) {
      const priorities = [];
      stepsData.forEach((stepData, index) => {
        const step = stepData.element;
        const type = stepData.type;
        const capturedPriority = step.getAttribute('data-captured-priority');
        if (capturedPriority) {
          priorities.push(capturedPriority);
          return;
        }
        let priority = 'low';
        if (type === 'error' || type === 'validation') {
          priority = 'critical';
        } else if (type === 'network') {
          const desc = step.querySelector('.step-description')?.textContent || '';
          if (desc.includes('\u274C')) priority = 'critical';
          else if (desc.includes('\u26A0\uFE0F')) priority = 'high';
          else priority = 'medium';
        } else if (type === 'click') {
          priority = 'high';
        } else if (type === 'input') {
          priority = 'high';
        } else if (type === 'navigation') {
          priority = 'high';
        } else if (type === 'scroll') {
          priority = 'low';
        }
        priorities.push(priority);
      });
      return priorities;
    }
    
    function updateCompactSummary(total, kept) {
      const removed = total - kept;
      const percentage = total > 0 ? Math.round((removed / total) * 100) : 0;
      document.getElementById('compactStats').innerHTML = 
        'Showing <strong>' + kept + '</strong> of ' + total + ' steps (' + percentage + '% hidden) - ' +
        'Showing only HIGH and CRITICAL priority actions (clicks, inputs, errors, failed requests)';
    }
`;function i(e){if(!e)return"";let n={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"};return String(e).replace(/[&<>"']/g,r=>n[r])}function F(e,n){let r=new Date().toLocaleString(),t=[...new Set(e.map(o=>o.type))];return`<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="Content-Security-Policy" content="script-src 'self'; object-src 'self'; style-src 'self' 'unsafe-inline'">
  <title>Bug Report - ${i(r)}</title>
  <style>${q}</style>
</head>
<body>
  ${G(r,e.length)}
  ${K(t,e.length)}
  ${Y(e.length)}
  ${Q()}
  ${Z(e,n)}
  ${ee()}
  <script>${H}<\/script>
</body>
</html>`}function G(e,n){return`
  <div class="header">
    <h1>\u{1F41B} Bug Recreation Report</h1>
    <div class="meta">Generated: ${i(e)}</div>
    <div class="meta">Total Steps: ${n}</div>
  </div>`}function K(e,n){return`
  <div class="filter-panel">
    <h3>\u{1F50D} Filter Steps</h3>
    <p>Select which step types to display:</p>
    <div class="filter-options">
      ${e.map(r=>`
        <div class="filter-option">
          <input type="checkbox" id="filter-${i(r)}" value="${i(r)}" checked onchange="filterSteps()">
          <label for="filter-${i(r)}">
            <span class="step-type type-${i(r)}">${i(r.toUpperCase())}</span>
          </label>
        </div>
      `).join("")}
    </div>
    <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #e2e8f0;">
      <div class="filter-option" style="width: 100%;">
        <input type="checkbox" id="filter-screenshots" checked onchange="toggleScreenshots()">
        <label for="filter-screenshots" style="font-weight: 500;">
          \u{1F4F8} Show Screenshots
        </label>
      </div>
      <div class="filter-option" style="width: 100%;">
        <input type="checkbox" id="filter-validation-only" onchange="toggleValidationOnly()">
        <label for="filter-validation-only" style="font-weight: 500;">
          \u26A0\uFE0F Show Only Validation Errors
        </label>
      </div>
      <div class="filter-option" style="width: 100%;">
        <input type="checkbox" id="filter-api-only" onchange="toggleAPIOnly()">
        <label for="filter-api-only" style="font-weight: 500;">
          \u{1F310} Show Only API Requests
        </label>
      </div>
    </div>
    <div class="filter-buttons">
      <button class="btn-compact" id="compactBtn" onclick="toggleCompactMode()" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">\u{1F3AF} Compact View</button>
    </div>
    <div class="visible-count" id="visibleCount">Showing ${n} of ${n} steps</div>
  </div>`}function Y(e){return`
  <div class="summary">
    <h2>\u{1F4CB} Summary</h2>
    <p>This report contains ${e} recorded steps to recreate the bug.</p>
    <p><strong>Follow these steps in order to reproduce the issue.</strong></p>
  </div>`}function Q(){return`
  <div class="compact-summary" id="compactSummary">
    <h3>\u{1F3AF} Compact Mode Active</h3>
    <p id="compactStats"></p>
  </div>`}function X(e,n,r,t){let o=[];e.type==="input"?(t.fieldLabel&&o.push("<strong>Field:</strong> "+i(t.fieldLabel)),t.value!==void 0&&t.value!==""&&o.push("<strong>Value:</strong> "+i(t.value)),t.fieldType&&t.fieldType!=="text"&&o.push("<strong>Type:</strong> "+i(t.fieldType)),t.path&&o.push('<strong>Path:</strong> <code style="font-size: 11px; background: #2d2d2d; padding: 2px 6px; border-radius: 3px; color: #9cdcfe;">'+i(t.path)+"</code>")):e.type==="click"?(t.label&&o.push("<strong>Element:</strong> "+i(t.label)),t.stepper&&o.push("<strong>Stepper:</strong> "+i(t.stepper)),t.text&&!t.label&&o.push("<strong>Text:</strong> "+i(t.text)),t.path&&o.push('<strong>Path:</strong> <code style="font-size: 11px; background: #2d2d2d; padding: 2px 6px; border-radius: 3px; color: #9cdcfe;">'+i(t.path)+"</code>")):e.type==="error"?(t.error&&o.push("<strong>Error:</strong> "+i(t.error)),t.file&&o.push("<strong>File:</strong> "+i(t.file)+":"+i(t.line||""))):e.type==="validation"&&(t.fieldLabel&&o.push("<strong>Field:</strong> "+i(t.fieldLabel)),t.status&&o.push('<strong>Status:</strong> <span style="color: #c62828; font-weight: 700;">\u274C Failed</span>'));let c=e.priority||"medium";return'<div class="step" data-type="'+i(e.type)+'" data-step-index="'+n+'" data-priority="'+i(c)+'" data-captured-priority="'+i(c)+'"><div class="step-header"><div style="display: flex; align-items: center; gap: 10px;"><span class="step-number">'+(n+1)+'</span><span class="step-type type-'+i(e.type)+'">'+i(e.type.toUpperCase())+"</span></div>"+(r.includeTimestamps?'<span class="step-time">'+i(new Date(e.timestamp).toLocaleTimeString())+"</span>":"")+'</div><div class="step-description">'+i(e.description)+"</div>"+(o.length>0?'<div class="step-details">'+o.map(function(s){return"<div>"+s+"</div>"}).join("")+"</div>":"")+(e.screenshot?'<img src="'+i(e.screenshot)+'" class="screenshot" alt="Screenshot" onmouseenter="expandScreenshot(this)" title="Hover to expand, click outside to collapse">':"")+"</div>"}function Z(e,n){return e.map((r,t)=>{let o=E(r),c=o.details||{};return o.type==="network"?J(o,t,n,c):X(o,t,n,c)}).join("")}function ee(){return`
  <div class="footer">
    <p>Generated by Bug Recorder Extension</p>
    <p>Use this report to help developers recreate and fix the bug</p>
  </div>`}function U(e){let n=new Blob([e],{type:"text/html"}),r=URL.createObjectURL(n),t=document.createElement("a");t.href=r,t.download=`bug-report-${Date.now()}.html`,t.click(),URL.revokeObjectURL(r)}function V(e,n){let r=new Date().toLocaleString(),t=`BUG RECREATION REPORT
`;return t+=`Generated: ${r}
`,t+=`Total Steps: ${e.length}
`,t+=`${"=".repeat(60)}

`,e.forEach((o,c)=>{let s=E(o);t+=`STEP ${c+1}: ${s.type.toUpperCase()}
`,n.includeTimestamps&&(t+=`Time: ${new Date(s.timestamp).toLocaleTimeString()}
`),t+=`Description: ${s.description}
`,s.details&&(s.details.fieldLabel&&(t+=`Field: ${s.details.fieldLabel}
`),s.details.label&&(t+=`Element: ${s.details.label}
`),s.details.stepper&&(t+=`Stepper: ${s.details.stepper}
`),s.details.value!==void 0&&(t+=`Value: ${s.details.value}
`),s.details.text&&!s.details.label&&(t+=`Text: ${s.details.text}
`),s.details.error&&(t+=`Error: ${s.details.error}
`),s.details.validationMessage&&(t+=`Validation: ${s.details.validationMessage}
`),s.details.method&&(t+=`Method: ${s.details.method}
`),s.details.status&&(t+=`Status: ${s.details.status}
`),s.details.duration&&(t+=`Duration: ${s.details.duration}ms
`),n.includeUrls&&s.url&&(t+=`URL: ${s.url}
`),s.details.requestBody&&(t+=`
Request Body:
`,t+=T(s.details.requestBody),t+=`
`),s.details.responseBody&&(t+=`
Response Body:
`,t+=T(s.details.responseBody),t+=`
`),s.details.errorMessage&&(t+=`Error Message: ${s.details.errorMessage}
`),s.details.fieldMappings&&s.details.fieldMappings.length>0&&(t+=`Field Mapping:
`,s.details.fieldMappings.forEach(d=>{t+=`  - ${d.propPath}: "${d.value}" <- from "${d.sourceField}"
`}))),t+=`${"-".repeat(60)}

`}),t}function N(e){var o,c,s,d,y,h,x;let n=te(e),r=[],t=0;for(;t<n.length;){let a=n[t];if(a.type==="click"&&re(a)){t++;continue}if(a.type==="click"&&t+1<n.length){let l=n[t+1];if(l.type==="click"&&oe(a)&&se(l)&&l.timestamp-a.timestamp<3e3){r.push({type:"input",description:`Selected "${((o=l.details)==null?void 0:o.text)||""}" in ${((c=a.details)==null?void 0:c.label)||"dropdown"}`,timestamp:a.timestamp,url:a.url,details:{fieldLabel:(s=a.details)==null?void 0:s.label,fieldType:"select",value:(d=l.details)==null?void 0:d.text,selector:(y=l.details)==null?void 0:y.selector}}),t+=2;continue}}if(a.type==="input"&&t+1<n.length){let l=n[t+1];if(l.type==="input"&&((h=a.details)==null?void 0:h.fieldName)===((x=l.details)==null?void 0:x.fieldName)&&l.timestamp-a.timestamp<100){r.push(a),t+=2;continue}}if(a.type==="navigation"&&t+1<n.length){let l=n[t+1];if(l.type==="navigation"&&a.url===l.url&&l.timestamp-a.timestamp<1e3){r.push(a),t+=2;continue}}r.push(a),t++}return r}function te(e){let n=new Map,r=[];for(let o of e){let c=ne(o),s=n.get(c);if(s){if(Math.abs(o.timestamp-s.timestamp)<j.DUPLICATE_STEP)continue;n.set(c,{timestamp:o.timestamp,index:r.length})}else n.set(c,{timestamp:o.timestamp,index:r.length});r.push(o)}return r}function ne(e){let n=e.details||{};switch(e.type){case"click":return`click:${n.label||n.text||n.selector||""}:${n.name||""}`;case"input":return`input:${n.fieldName||n.fieldLabel||n.selector||""}:${n.value||""}`;case"navigation":return`navigation:${e.url||""}`;case"scroll":let r=Math.round((n.x||0)/100)*100,t=Math.round((n.y||0)/100)*100;return`scroll:${r}:${t}`;case"validation":return`validation:${n.fieldName||n.fieldLabel||""}:${n.validationMessage||""}`;case"error":return`error:${n.error||e.description||""}`;case"network":let o=P(n.url||"");return`network:${n.method||""}:${o}:${n.status||""}`;default:return`${e.type}:${e.description||""}`}}function re(e){var r;let n=e.details||{};return!!(n.element==="div"&&!n.text&&!n.label||n.element==="span"&&!n.text&&!n.label||(r=n.selector)!=null&&r.includes("mat-select-value")&&!n.text)}function oe(e){var r,t,o;let n=e.details||{};return n.label||((r=n.selector)==null?void 0:r.includes("mat-select"))||((t=n.selector)==null?void 0:t.includes("mat-form-field"))||((o=n.text)==null?void 0:o.toLowerCase().includes("select"))}function se(e){var r,t;let n=e.details||{};return((r=n.selector)==null?void 0:r.includes("mat-option"))||((t=n.name)==null?void 0:t.includes("mat-option"))}var p=!1,$=null;document.addEventListener("DOMContentLoaded",async()=>{var n;let e=await w(["isRecording","steps","settings","recordingSessionId","activeSessionDomain"]);if(p=e.isRecording||!1,$=e.recordingSessionId||null,v(p),b(((n=e.steps)==null?void 0:n.length)||0),A(e.settings),D(),p)try{let[r]=await chrome.tabs.query({active:!0,currentWindow:!0}),t=await chrome.tabs.sendMessage(r.id,{action:m.GET_STATUS});t&&!t.isRecording&&(p=!1,await k({isRecording:!1}),v(p))}catch{}});document.getElementById("startBtn").addEventListener("click",async()=>{let e=C(),[n]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!n||!n.url){alert("Unable to determine current tab URL. Please try again.");return}let r;try{r=new URL(n.url).hostname}catch{alert("Unable to start recording on this page.");return}let t,o=!0;try{let s=await chrome.runtime.sendMessage({action:m.START_SESSION,domain:r,settings:e});if(!s||!s.success){alert("Could not start recording. Please try again.");return}t=s.sessionId,o=!!s.isNewSession}catch{alert("Could not start recording. Please try again.");return}$=t,o&&b(0);let c=!1;try{await chrome.tabs.sendMessage(n.id,{action:m.START_RECORDING,settings:e,sessionId:t,isNewSession:o}),c=!0}catch{try{await chrome.scripting.executeScript({target:{tabId:n.id},files:["content.js"]}),await new Promise(d=>setTimeout(d,100)),await chrome.tabs.sendMessage(n.id,{action:m.START_RECORDING,settings:e,sessionId:t,isNewSession:o}),c=!0}catch{alert("Please refresh the page and try again");return}}c&&(p=!0,v(p))});document.getElementById("stopBtn").addEventListener("click",async()=>{let[e]=await chrome.tabs.query({active:!0,currentWindow:!0});try{await chrome.tabs.sendMessage(e.id,{action:m.STOP_RECORDING})}catch{}await new Promise(r=>setTimeout(r,200));try{await chrome.runtime.sendMessage({action:m.STOP_SESSION})}catch{}p=!1,$=null,v(p);let{steps:n}=await w(["steps"]);b((n==null?void 0:n.length)||0)});document.getElementById("exportBtn").addEventListener("click",async()=>{let{steps:e,settings:n}=await w(["steps","settings"]);if(!e||e.length===0){alert("No steps recorded yet. Start recording and perform some actions first.");return}let r=N(e),t=F(r,n||{});U(t)});document.getElementById("copyBtn").addEventListener("click",async()=>{let{steps:e,settings:n}=await w(["steps","settings"]);if(!e||e.length===0){alert("No steps recorded yet. Start recording and perform some actions first.");return}let r=N(e),t=V(r,n||{});await navigator.clipboard.writeText(t),alert("Report copied to clipboard!")});document.getElementById("clearBtn").addEventListener("click",async()=>{confirm("Clear all recorded steps?")&&(await k({steps:[]}),b(0))});O(e=>{e.steps&&b(e.steps.length)});})();
